#include <stdio.h>

int iCost,
    tax,
    total,
    fuelCost,
    houseCost;
double taxRate;

int housecost(int fuelCost, int tax)
{
    total = fuelCost * 5 + tax * 5;
    return total;
}

int main()
{
    printf("Enter the Annual Fuel Cost : ");
    scanf("%d", &fuelCost);
    printf("Enter the Initial Cost : ");
    scanf("%d", &iCost);
    printf("Enter the Tax Rate : ");
    scanf("%lf", &taxRate);

    tax = taxRate * iCost;

    houseCost = housecost(fuelCost, tax);
    printf("%d", houseCost);
}