#include <stdio.h>
#include <stdlib.h>

/*
Anggota Kelompok :

Ligar Arsa Arnata 5025211244
Sony Hermawan 5025211226
Immanuel Pascanov Samosir 5025211257 

*/


int main()
{
// 1. Car Payment

// Variable Declaration
    double purchase_price, down_payment, annual_interest_rate, total_number_of_payments;
// Get the Amount of Purchase Price
    printf("Enter the Purchase Price : ");
    scanf("%lf", &purchase_price);
// Get the Amount of Down payment
    printf("Enter the Down Payment : ");
    scanf("%lf", &down_payment);
// Get the Amount of annual interest rate
    printf("Enter the Annual Interest Rate : ");
    scanf("%lf", &annual_interest_rate);
// Get the Amount of total number of payments
    printf("Enter the Total Number of Payments : ");
    scanf("%lf", &total_number_of_payments);
// Calculate Monthly Interest Rate
    double monthly_interest_rate = annual_interest_rate / 12;
// Calculate the Amount Borrowed
    double borrowed = purchase_price-down_payment;
// Calculate the Payment
    double payment = monthly_interest_rate * borrowed  / 1 - 1 / pow((1 + monthly_interest_rate), total_number_of_payments);
// Display the Amount Borrowed and the Monthly Payment
    printf(" The Amount Borrowed : $%.2f \n", borrowed);
    printf(" The Monthly Payment : $%.2f", payment);
    return 0;
}
