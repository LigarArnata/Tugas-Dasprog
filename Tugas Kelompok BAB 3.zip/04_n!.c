#include <stdio.h>
#include <stdlib.h>

int main()
{
// 4. n!

// Variable Declaration
    double n;
// Get the Value of Integer
    printf("Enter Integer : ");
    scanf("%lf", &n);
// Calculate n! with Gosper's Formula
    double n_factorial = pow(n,n) * exp(-n) * sqrt((2 * n + 1/3) * PI);
// Display the Result
    printf("%.2f ! equals approximately %f ", n, n_factorial);

    return 0;
}
