#include <stdio.h>
#include <stdlib.h>

int main()
{
// 2. Circle and Trapezium

// Draw Circle
    void
    draw_circle(void)
{
    printf("     * \n");
    printf("   *   *\n");
    printf("    * * \n");
}
// Draw Ceil
    void
    draw_ceil(void)
{
    printf("   ------ \n");
}
// Draw Hypotenuse
    void
    draw_hypotenuse(void)
{
    printf("  /      \\ \n");
    printf(" /        \\ \n");
    printf("/          \\ \n");
}
// Draw Base
    void
    draw_base(void)
{
    printf("-------------");
}
// Draw Trapezium
    void
    draw_trapezium(void)
{
    draw_ceil();
    draw_hypotenuse();
    draw_base();
}
// Display one blank line
    void
    draw_blank(void)
{
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");
}
// Draw Circle
draw_circle();
// Draw Trapezium
draw_trapezium();
// Display one blank line
draw_blank();
// Draw Circle
draw_circle();
// Draw Trapezium
draw_trapezium();

    return 0;
}
