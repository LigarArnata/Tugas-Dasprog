#include <stdio.h>

double m,
    s,
    sfps,
    smps,
    feetMile = 5280,
    meterMile = 1609.34,
    ansfps,
    ansmps;

double speedfps(double m, double s)
{
    sfps = feetMile / (m * 60 + s);
    return sfps;
}

double speedmps(double m, double s)
{
    smps = meterMile / (m * 60 + s);
    return smps;
}

int main()
{
    printf("Enter Minutes : ");
    scanf("%lf", &m);
    printf("Enter Seconds : ");
    scanf("%lf", &s);

    ansfps = speedfps(m, s);
    printf("%.1f feet per second \n", ansfps);

    ansmps = speedmps(m, s);
    printf("%.1f meter per second \n", ansmps);
}