#include <stdio.h>
#include <stdlib.h>

int main()
{
// 5. Laptop Payment

// Variable Declaration
    double total_price, hourly_income, down_payment, annual_interest_rate, total_number_of_payments;
// Get the Amount of Total Price
    printf("Enter Total Price : ");
    scanf("%lf", &total_price);
// Get the Amount of Hourly Income
    printf("Enter Hourly Income : ");
    scanf("%lf", &hourly_income);
// Get the Amount of Down payment
    printf("Enter the Down Payment : ");
    scanf("%lf", &down_payment);
// Get the Amount of annual interest rate
    printf("Enter the Annual Interest Rate : ");
    scanf("%lf", &annual_interest_rate);
// Get the Amount of total number of payments
    printf("Enter the Total Number of Payments : ");
    scanf("%lf", &total_number_of_payments);
// Calculate Monthly Interest Rate
    double monthly_interest_rate = annual_interest_rate / 12;
// Calculate the Amount Borrowed
    double borrowed = total_price-down_payment;
// Calculate the Payment
    double payment = monthly_interest_rate * borrowed  / 1 - 1 / pow((1 + monthly_interest_rate), total_number_of_payments);
// Calculate Total Hours
    double total_hours = payment / hourly_income;
// Display the Result
    printf("You need to work total %.2f hours ", total_hours);

    return 0;
}
