#include <stdio.h>

double cel,
    fah,
    anscel,
    ansfah;

int depth;

double celcius_at_depth(int depth)
{
    cel = 10 * depth + 20;
    return cel;
}

double fahrenheit(int celcius)
{
    fah = 1.8 * celcius + 32;
    return fah;
}

int main()
{
    printf("Enter depth : ");
    scanf("%d", &depth);
    anscel = celcius_at_depth(depth);
    printf("Temperature in Celcius : ");

    printf("%1.f C\n", anscel);

    printf("Temperature in Fahrenheit : ");
    ansfah = fahrenheit(anscel);
    printf("%1.f F\n", ansfah);
}