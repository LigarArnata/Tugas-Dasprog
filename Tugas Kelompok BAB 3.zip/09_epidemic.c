#include <stdio.h>

int day,
    caseDayN,
    ans;

int caseIncrease(int day)
{
    day = day + (day * 0.28);
    return day;
}

int main()
{
    printf("Enter day number : ");
    scanf("%d", &day);

    ans = caseIncrease(day);
    printf("By day %d, model predicts %d cases total\n", day, ans);

    printf("Enter day number : ");
    scanf("%d", &day);

    ans = caseIncrease(day);
    printf("By day %d, model predicts %d cases total\n", day, ans);

    printf("Enter day number : ");
    scanf("%d", &day);

    ans = caseIncrease(day);
    printf("By day %d, model predicts %d cases total\n", day, ans);
}