#include <stdio.h>

int main(){
	int a, b, t;
	printf ("Enter a year after 1990 : ");
	scanf("%d", &a);
	if(a <= 1990)
	{  printf("Enter a year after 1990!");
	}else {
	t = a-1990;
	b = 52966+ (2184*t);
	printf ("Population predict : %d", b);
	}
	return 0;
}
