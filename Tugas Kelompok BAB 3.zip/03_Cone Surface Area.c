#include <stdio.h>
#include <stdlib.h>

int main()
{
// 3. Cone Surface Area

// Variable Declaration
    double radius, slant_height;
// Get the Value of Radius
    printf("Enter the Radius : ");
    scanf("%lf", &radius);
// Get the Value of Cone Slant Height
    printf("Enter the Slant Height : ");
    scanf("%lf", &slant_height);
// Calculate the Surface Area
    double surface_area = PI * radius *( radius + slant_height);
// Display the Value of Surface Area
    printf("The Surface Area : %.2f", surface_area);

    return 0;
}
