#include <stdio.h>
#include <math.h>

int main(){
    int a, T, x, y;
    printf("Temperature (F) : ");
    scanf("%d", &T);
    x=((5*T)+297)/247;
    y= sqrt(x);
    a=1086*x;
    printf("Speed of sound : %d", a);
    return 0;
}
