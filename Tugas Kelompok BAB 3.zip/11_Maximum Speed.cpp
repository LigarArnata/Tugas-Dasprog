#include <stdio.h>
#include <math.h>

int main(){
	int a, b, c, rpm;
	printf ("Enter the maximum speed: ");
	scanf("%d", &a);
	printf ("Enter the minimum speed: ");
	scanf("%d", &b);;
	c=a/b;
	rpm=pow(c,0.2);
	
	printf ("The ratio between successive speeds of a six-speed gearbox with maximum speed %d", a);
	printf (" rpm and minimum speed %d", b);
	printf (" rpm is %d", rpm);
	
	return 0;
}
