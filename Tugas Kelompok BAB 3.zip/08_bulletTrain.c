#include <stdio.h>

int a,
    t,
    vf,
    vi,
    accel;

int acceleration(int t, int vi, int vf)
{
    a = (vf - vi) / 2;
    return a;
}

int main()
{
    // vf = (vi - (t - 1) * 50);
    printf("Enter Time : ");
    scanf("%d", &t);
    printf("Enter Initial Velocity : ");
    scanf("%d", &vi);
    printf("Enter Final Velocity : ");
    scanf("%d", &vf);

    accel = acceleration(t, vi, vf);
    printf("Acceleration is %d", accel);
}