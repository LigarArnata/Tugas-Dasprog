#include <stdio.h>
#define MAX_CREWS 3
#define MAX_JOBS 25
//Ligar Arsa Arnata - 5025211244

typedef struct {
    int level, cost, hours_so_far;
} crew_t;

typedef struct
{
    int id, level, hours, crew, start_hours;
} work_t;

void get_crew(crew_t crew[], int *num_crews);
void get_work(work_t work[], int *num_jobs);
void match_crew_work(crew_t crew[], work_t *work, int n_crews, int *min_cost_crew);
void earliest_time(crew_t crew[], work_t *work, int n_crews, int *min_time_crew);
void print_schedule(crew_t crew[], work_t work[], int n_crews, int n_jobs);
