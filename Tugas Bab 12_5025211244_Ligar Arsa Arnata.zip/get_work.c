#include "header.h"
//Ligar Arsa Arnata - 5025211244

void get_work(work_t work[], int *num_jobs)
{
    int i;

    printf("\nEnter the number of maintenance jobs-> ");
    scanf("%d",num_jobs);

    while((*num_jobs <= 0) || (*num_jobs >MAX_JOBS))
    {
        printf("Number is out of range. Maximum=%d. Try again-> ",MAX_JOBS);
        scanf("%d",num_jobs);
    }

    printf("For each job: input an id (4-digit integer), a skill level and estimated hours.\n");

    for(i=0; i<*num_jobs; i++)
    {
        scanf("%d%d%d", &work[i].id, &work[i].level, &work[i].hours);
        work[i].crew =0;
        work[i].start_hours =0;
    }
    printf("\nsucces\n");
}

