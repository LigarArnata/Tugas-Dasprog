#include "header.h"
//Ligar Arsa Arnata - 5025211244

int main(void)
{
    crew_t crew[MAX_CREWS];
    work_t jobs[MAX_JOBS];
    char testchar[10];
    int n_crews,n_jobs, output_crew, order[MAX_JOBS];
    int temp,i,j;

    get_crew(crew,&n_crews);
    get_work(jobs,&n_jobs);

    for(i=0; i<n_jobs; i++)
    {
        match_crew_work(crew,&jobs[i],n_crews, &output_crew);
        jobs[i].crew =output_crew;
        jobs[i].start_hours =crew[output_crew].hours_so_far;
        crew[output_crew].hours_so_far+=jobs[i].hours;
    }

    printf("\n\nLOWEST COST SCHEDULE \n");

    print_schedule(crew, jobs,n_crews,n_jobs);

    for(i=0; i<n_jobs; i++)
    {
        jobs[i].crew = -1;
        jobs[i].start_hours =0;
    }

    for(i=0; i<n_crews; i++)
    {
        crew[i].hours_so_far =0;
    }

    for(i=0; i<n_jobs; i++)
    {
        order[i] =i;
    }

    for(i=0; i<n_jobs; i++)
    {
        for(j=i; j<n_jobs; j++)
        {
            if(jobs[i].level)
            temp=order[i];
            order[i]=order[j];
            order[j]=temp;
        }
    }

    for(i=0; i<n_jobs; i++)
    {
        j=order[i];
        earliest_time(crew,&jobs[j],n_crews, &output_crew);
        jobs[j].crew =output_crew;
        jobs[j].start_hours= crew[output_crew].hours_so_far;
        crew[output_crew].hours_so_far +=jobs[j].hours;
    }

    printf("\n\nFASTEST SCHEDULE\n");
    print_schedule(crew, jobs,n_crews, n_jobs);
    return (0);
}
