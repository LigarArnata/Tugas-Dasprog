#include "header.h"
//Ligar Arsa Arnata - 5025211244

void match_crew_work(crew_t crew[], work_t *work, int n_crews, int *min_cost_crew)
{
    int i,flag=0;
    *min_cost_crew=0;
    printf("SS %d\n", work->level);
    for(i=0; i<n_crews; i++)
    {
        if((work->level <=crew[i].level) && ( (crew[i].cost <=crew[*min_cost_crew].cost) || (flag ==0)))
        {
            *min_cost_crew =i;
            flag =1;
        }
    }

    if(flag ==0)
    {
        printf("No crew of required skill level available. Exit.\n");
        exit(1);
    }
}
