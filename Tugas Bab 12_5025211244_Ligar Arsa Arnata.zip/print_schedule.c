#include "header.h"
//Ligar Arsa Arnata - 5025211244

void print_schedule(crew_t crew[], work_t work[],int n_crews, int n_jobs)
{
    int i, earliest_time =-1;
    int end_time, total_cost=0;

    printf("\nJOB \tSTART TIME\t END_TIME\tCREW\n");

    for(i=0; i<n_jobs; i++)
    {
        end_time = work[i].start_hours +work[i].hours;
        printf("%4d\t%10d\t%9d\t%4d\n", work[i].id,work[i].start_hours, end_time, work[i].crew); total_cost +=crew[work[i].crew].cost * work[i].hours;

        if (end_time > earliest_time)
        earliest_time=end_time;
    }

    printf("\nALL JOBS WILL BE FINISHED IN %d HOURS AT A COST OF $%d\n", earliest_time, total_cost);
}

