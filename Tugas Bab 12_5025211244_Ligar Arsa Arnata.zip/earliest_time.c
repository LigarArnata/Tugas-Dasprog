#include "header.h"
//Ligar Arsa Arnata - 5025211244

void earliest_time(crew_t crew[], work_t *work, int n_crews, int *min_time_crew)
{
    int i,flag = 0;
    *min_time_crew =0;
    printf("%d\n", work->level);
    for(i=0; i<n_crews; i++)
    {
        if((crew[i].level >=work->level) && ((crew[i].hours_so_far<=crew[*min_time_crew].hours_so_far)|| (flag ==0)))
        {
            *min_time_crew =i;
            flag =1;
        }

        else if((crew[i].hours_so_far == crew[*min_time_crew].hours_so_far) && (crew[i].level >= work->level) && ((crew[i].cost >= crew[*min_time_crew].cost)|| (flag ==0)))
        {
            *min_time_crew =i;
            flag =1;
        }
    }

    if(flag ==0)
    {
        printf("No crew of required skill level available. Exit. \n");
        exit(1);
    }
}
