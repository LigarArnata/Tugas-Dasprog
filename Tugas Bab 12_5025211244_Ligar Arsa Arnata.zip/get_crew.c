#include "header.h"
//Ligar Arsa Arnata - 5025211244

void get_crew(crew_t crew[], int *num_crews)
{
    int i;

    printf("Enter the number of crews-> ");
    scanf("%d",num_crews);

    while((*num_crews <=0) || (*num_crews>MAX_CREWS))
    {
        printf("Number is out of range. Maximum=%d. Try again-> ",MAX_CREWS);
        scanf("%d",num_crews);
    }

    printf("For each crew: input a skill level and cost per hour. \n");

    for(i=0; i<*num_crews; i++)
    {
        scanf("%d%d",&crew[i].level, &crew[i].cost);
        crew[i].hours_so_far =0;
    }
}
