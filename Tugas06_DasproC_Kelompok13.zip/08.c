#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#define flatrate 7.99
#define extrarate 1.99

void charges (double hours, double *charge, double *avg);

double round_money (double number);

int
main ()
{
	FILE *inp = fopen("usage.txt", "r");
	FILE *outp = fopen("charges.txt", "w");

	int month, year, customer;
	double hours, charge, avg;

	fscanf(inp, "%d%d", &month, &year);

	fprintf(outp, "Charges for %d/%d\n", month, year);
	fprintf(outp, "                             Charge");
	fprintf(outp, "\nCustomer     Hours Used     per hour     Average cost");

	while (fscanf(inp, "%d", &customer) !=-1)
	{
		fscanf(inp, "%lf", &hours);

		charges (hours, &charge, &avg);

		fprintf(outp, "\n%d", customer);

		if (hours>=10 && hours<100)
		{
			fprintf(outp,"          %.1lf          %.2lf           %.2lf", hours, charge, avg);
		}

		else if (hours<10)
		{
			fprintf(outp,"           %.1lf           %.2lf           %.2lf", hours, charge, avg);
		}

		else if (hours>=100 && hours<1000)
		{
			fprintf(outp,"         %.1lf         %.2lf           %.2lf", hours, charge, avg);
		}

		else if (hours>=1000 && hours<10000)
		{
			fprintf(outp,"        %.1lf        %.2lf           %.2lf", hours, charge, avg);
		}
	}

	return 0;
}

void
charges (double hours, double *charge, double *avg)
{

	if (hours<=10)
	{
		*charge = flatrate;
	}

	else
	{
		*charge = flatrate + ((ceil(hours)-10)*extrarate);
	}

	*charge = round_money(*charge);
	*avg = *charge / hours;
	*avg = round_money(*avg);
}

double
round_money (double number)
{
	number = round(number*100)/100;
	return number;
}
