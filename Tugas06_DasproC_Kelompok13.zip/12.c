#include <stdio.h>
#include <stdlib.h>

void find_checksum(int, int*);
void process(char ch);

int main()
{
    char ch;

    printf("\n====================================== CHECKSUM PROGRAM ======================================\n\n");
    printf("Note :\tEnter the line with a dot (.) at the end of line to printout Checksum, Example : Test.\n");
    printf("\tEnter the line with a dot (.) to end the program, Example : .\n\n");
    printf("==============================================================================================\n\n");

    printf("Enter the Line to Find Checksum => ");
    process(ch);

    return 0;
}

void process(char ch)
{
    int sum, checksum;

    sum = (int)'.';
    sum += (int)ch;

    scanf(" %c", &ch);

    while(ch != '.')
    {
        sum += ((int)ch);
        scanf(" %c", &ch);
    }

    find_checksum(sum, &checksum);
    printf("Checksum => %c \n\n", (char)checksum);

    printf("Enter the Line to Find Checksum => ");
    scanf(" %c", &ch);

    if(ch != '.')
    {
        process(ch);
    }
}

void find_checksum(int sum, int *checksum)
{
    sum %= 64;
    *checksum = sum + (int)' ';
}
