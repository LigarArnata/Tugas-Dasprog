#include<stdio.h>
#include<math.h>

//function to calculate R in a certain year
double annual_revenue(int*);

//function to get predicted year
int predict_year(double);

int main(){
	printf("YEAR	||		REVENUE\n");
	printf("===============================\n");
	predict_year(1000000);
}

double annual_revenue(int* t){
	double R;
	R = 471.621 * pow(1.063, *t);
	ceil(1000*R)/1000;
	printf("%d	||	  %13.3f\n", *t+1990, R);
	return R;
}

int predict_year(double dollars){
	int t = 0;
	while(annual_revenue(&t) < dollars){
		t++;
	}
}
