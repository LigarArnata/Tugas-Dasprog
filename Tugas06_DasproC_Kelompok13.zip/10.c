#include <stdio.h>
//fungsi sum, min, kali, bagi, faktorial, quit program, bad input data
void penjumlahan (double, double, double*);
void pengurangan (float, float, float*);
void perkalian (float, float, float*);
void pembagian (float, float, float*);
void factorial (int, int*);

int main()
{
	int x, y;

	for(y=0;y>=0;y++)
	{
		printf("Masukkan angka antara 1-6 : ");
		scanf("%d", &x);

		if(x == 1)
		{
			double m, n, sum;
			printf("Masukkan 2 bilangan : ");
			scanf("%lf%lf", &m, &n);

			penjumlahan(m, n, &sum);

			printf("Jumlah kedua bilangan adalah : %.2lf\n", sum);
		}
		else if(x == 2)
		{
			float m, n, min;
			printf("Masukkan 2 bilangan : ");
			scanf("%f%f", &m, &n);

			pengurangan(m, n, &min);

			printf("Hasil pengurangan kedua bilangan adalah : %.2f\n", min);
		}
		else if(x == 3)
		{
			float m, n, kali;
			printf("Masukkan 2 bilangan : ");
			scanf("%f%f", &m, &n);

			perkalian(m, n, &kali);

			printf("Hasil perkalian kedua bilangan adalah : %.2f\n", kali);
		}
		else if(x == 4)
		{
			float m, n, bagi;
			printf("Masukkan 2 bilangan : ");
			scanf("%f%f", &m, &n);

			pembagian(m, n, &bagi);

			printf("Hasil pembagian kedua bilangan adalah : %.2f\n", bagi);
		}
		else if(x == 5)
		{
			int m, faktorial = 1;
			printf("Masukkan bilangan : ");
			scanf("%d", &m);

			factorial(m, &faktorial);

			if(m>0)
			{
				printf("Faktorial dari %d! adalah : %d\n", m, faktorial);
			}
			else
			{
				printf("bilangan ini tidak memliki faktorial\n");
			}
		}
		else if(x == 6)
		{
			return 0;
		}
		else
		{
			printf("bad input data\n");
		}
	}

	return 0;
}

void penjumlahan(double a, double b, double *sums)
{
	*sums = a + b;
}

void pengurangan(float a, float b, float *mins)
{
	*mins = a - b;
}

void perkalian(float a, float b, float *kalis)
{
	*kalis = a * b;
}

void pembagian(float a, float b, float *bagis)
{
	*bagis = a / b;
}

void factorial(int a, int *faktorials)
{
	int i;
 	for(i=1;i<=a;i++)
    	{
     		*faktorials = *faktorials * i;
   		}
}
