#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//prototype function declare
void get_rate_drop_factor(double* , double*);
void get_kg_rate_conc(double* , double* , double*);
void get_units_conc(double* , double*);
void fig_drops_min(double , double*);
void fig_ml_hr(double, double* );
void by_weight(double , double , double*);
void by_units(double , double*);
void get_problem(void);
//main fucntion
int main(void)
{
    //Calling get_problem Function
    get_problem();
    return 0;
}
//Take problems form user to compute
void get_problem(){

    int prob; //Type of problem variable
    double rate, //rate variable
           drops, //drops variable
           hour, //hours variable
           weight, //Weight variable
           conce; //Concentration variable
    //controlled loop while problem is not '5'
    do{
    printf("\nINTRAVENOUS RATE ASSISTANT\n");
    printf("\nEnter the number of problem you wish to solve\n");
    printf("\tGIVEN A MEDICAL ORDER IN                CALCUALTE RATE IN\n");
    printf("(1) ml/hr & tubing drop factor             \tdrops / min\n");
    printf("(2) 1 L for n hr                          \tml / hr\n");
    printf("(3) mg/kg/hr & concentration in mg/ml     \tml / hr\n");
    printf("(4) units/hr & concentration in units/ml  \tml / hr\n");
    printf("(5) QUIT\n");
    printf("\nProblem> ");
    //takes problem input
    scanf("%d", &prob);
    //conditional operation
    switch(prob){
        case 1:
            get_rate_drop_factor(&drops, &rate);/*calling get_rate_drop function
                                                  use drops and rate as output argument*/

            fig_drops_min(drops, &rate);        /*calling fig_drops_min to get rate value
                                                  using drops as input argument*/

            printf("The drop rate per minute is %.1lf\n", rate); //rate drop/minute output
            break;
        case 2:
            printf("Enter number of hours=> "); //Take hours input
            scanf("%lf", &hour);

            fig_ml_hr(hour, &rate);/*calling fig_ml_hr function using hour as input
                                     and rate as output argument*/

            printf("The rate in milliliters per hour is %.2lf\n", rate); //rate ml/hour output
            break;
        case 3:
            get_kg_rate_conc(&weight, &conce, &rate); /*calling get_kg_rate_conc function using
                                                        weight, conce, and rate as output argument*/

            by_weight(weight, conce, &rate);          /*calling by_weight function using weight,
                                                        conce as input and rate as output argument*/

            printf("The rate in milliliters per hour is %.2lf\n", rate);//rate ml/hour output
            break;
        case 4:
            get_units_conc(&conce, &rate); //calling get_units_conc function and use conce and rate as output arguments

            by_units(conce, &rate);//calling by_units function and using conce as input and rate as output arguments

            printf("The rate in milliliters per hour is %.2lf\n", rate);//rate ml/hour output
            break;
        case 5: break;//end looping
        //if problem input is more than 5
        default:
            system("cls");
            printf("Invalid input\n");
            break;
    }
    }while(prob != 5);
}
void get_rate_drop_factor(double* drops, double* rate){
    printf("Enter rate in ml/hr=> ");
    scanf("%lf", rate); //storing value in rate
    printf("Enter tubing's drop factor(drops/ml)=> ");
    scanf("%lf", drops); //storing value in drops
}
void get_kg_rate_conc(double* weight, double* conce, double* rate){
    printf("Enter rate in mg/kg/hr=> ");
    scanf("%lf", rate); //storing value in rate
    printf("Enter patient weight in kg=> ");
    scanf("%lf", weight); //storing value in weight
    printf("Enter concentration in mg/ml=> ");
    scanf("%lf", conce); //storing value in conce

}
void get_units_conc(double* conce, double* rate){
    printf("Enter rate in units/hr=> ");
    scanf("%lf", rate);//storing value in rate
    printf("Enter concentration in units/ml=> ");
    scanf("%lf", conce);//storing value in conce
}
void fig_drops_min(double drops, double* rate){
    *rate = round((*rate/60)* drops); //calculating rate value in drop/min
}
void fig_ml_hr(double hour, double* rate){
    *rate = round(1000/hour); //calculating rate value in ml/hour
}
void by_weight(double weight, double conce, double* rate){
    *rate = round((*rate * weight)/conce); //calculation rate in ml/hour
}
void by_units(double conce, double*rate){
    *rate = round(*rate/conce); //calculating rate value in ml/hour
}
