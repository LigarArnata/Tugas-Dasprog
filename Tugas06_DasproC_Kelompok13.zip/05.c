#include <stdio.h>
#include <stdlib.h>

void proses(int);

int main()
{
    int number;
	printf("Enter some positive integer =  ");
	scanf("%d", &number);
    proses(number);
    return 0;
}

void proses(int number)
{
	int reverse = 0;
    int n=number;
    int r=0;
    int y=1;

    printf("\n%d", number);

	// Reverse Number
    while (number != 0) {
       reverse = reverse*10 + number%10;
       number = number / 10;
    }
    printf("\na. Reversed Number= %d\n", reverse);

	// Prime or not
    if (n <=1){
        printf("b. %d is not a Prime Number\n", n);
    }
    for (y ; y<=n ; y++){
        if (n%y == 0) r++;
    }
    if (r == 2) {
	printf("b. %d is a Prime Number\n", n);
	}
    else {
	printf("b. %d is not a Prime Number\n", n);
	}

	// Palindrome or not
    if (n==reverse){
        printf("c. %d is a Palindrome\n", n);
    } else {
        printf("c. %d is not a Palindrome\n", n);
    }

	scanf("%d", &number);
	proses(number);
}
