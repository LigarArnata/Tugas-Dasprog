#include <stdio.h>
#include <math.h>

int main()
{
	double e, rumus, eksp, selisih;
	int x;
	e = exp(1);
	x = 1;

	do
	{
		rumus = ((2.0 * x + 1) / (2.0 * x - 1));
		eksp = pow(rumus, x);
		selisih = eksp - e;
		x += 1;
	}
	while (selisih >= 0.0000009);

	printf("x = %d\n", x);
	printf("e = %.7f\n", e);
	printf("exp e = %.7f", eksp);
}
