#include <stdio.h>
#define PI 3.14
int main (){
	int a=0;
	while (a==0)
	{
		int choose;

		 printf("\nEnter the number of the problem you wish to solve.\n");
		 printf("(1) Area of a parallelogram      ");
		 printf("(4) Area of a circle\n");
		 printf("(2) Area of a triangle           ");
		 printf("(5) QUIT\n");
		 printf("(3) Area of a trapezoid\n");

		scanf("%d", &choose);

		if (choose == 1){
			double a, b, area;

			printf("Enter the base :");
			scanf("%lf", &a);
			printf("Enter the height :");
			scanf("%lf", &b);

			parallel(a, b, &area);

		}else if (choose == 2){
			double a, b, area;

			printf("Enter the base :");
			scanf("%lf", &a);
			printf("Enter the height :");
			scanf("%lf", &b);

			triangle(a, b, &area);

		}else if (choose == 3){
			double a, b, c, area;

			printf("Enter the a-base :");
			scanf("%lf", &a);
			printf("Enter the b-base :");
			scanf("%lf", &b);
			printf("Enter the height :");
			scanf("%lf", &c);

			trapezoid(a, b, c, &area);

		}else if (choose == 4){
			double a, area;

			printf("Enter the radius :");
			scanf("%lf", &a);

			circle(a, &area);

		}else {
			return 0;
		}
	}
}

int parallel (double a, double b, double *area)
{
	*area = a * b;
	printf("The Area of Parallelogram is %.2lf\n", *area);
}

int triangle (double a, double b, double *area)
{
	*area = 0.5 * a * b;
	printf("The Area of Triangle is %.2lf\n", *area);
}

int trapezoid (double a, double b, double c, double *area)
{
	*area = (a+b) * 0.5 * c;
	printf("The Area of Trapezoid is %.2lf\n", *area);
}

int circle (double a, double *area)
{
	*area = PI * a * a;
	printf("The Area of Circle is %.2lf\n", *area);
}
