#include <stdio.h>
#include <stdlib.h>

// 4. Odd and Even Number

// A

int main()
{
// Variable Declaration
 int a[1000],i,n,even=0,odd=0;
// Get the size of array
 printf("Enter size of the array : ");
 scanf("%d",&n);

 printf("Enter elements in array : ");
 for(i=0; i<n; i++){
    scanf("%d",&a[i]);
}
for(i=0; i<n; i++){
    if(a[i]%2==0)
        even++;
    else
        odd++;
}
 printf("even numbers in array: %d",even);
 printf("\n odd numbers in array: %d",odd);

// B

void main()
{
    int i, num, odd_sum = 0, even_sum = 0;
 
    printf("Enter the value of num\n");
    scanf("%d", &num);
    for (i = 1; i <= num; i++)
    {
        if (i % 2 == 0)
            even_sum = even_sum + i;
        else
            odd_sum = odd_sum + i;
    }
    printf("Sum of all odd numbers  = %d\n", odd_sum);
    printf("Sum of all even numbers = %d\n", even_sum);
}
    return 0;
}
