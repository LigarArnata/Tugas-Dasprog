#include <stdio.h>
#include <stdlib.h>

int main()
{

// 3. Loan Amortization Table

// Variable Declaration
 int num_payments, Principle;
 float InterestRate, i, n, p, PaymentAmount;
// Get Loan Amount
printf("Please enter loan amount: ");
scanf("%d", &Principle);
// Get Annual Interest Rate
 printf("\nPlease enter annual interest rate: ");
 scanf("%f", &InterestRate);
// Get The Number of Payments
 printf("\nPlease enter the number of payments: ");
 scanf("%d", &num_payments);
 i = InterestRate/12;
 n = num_payments;
 p = Principle;
// While Statement
 while (num_payments>0)
 {
  PaymentAmount = (i*p)/(1-pow((1+i),-n));
  p = p - PaymentAmount + ((i/100)*p);
  n = n-1;
  printf ("\nNumber of Payments: %d           Amount per payment: %f\n", num_payments, PaymentAmount);
  num_payments = num_payments - 1;
 }
 getchar ();
 return 0;
}



