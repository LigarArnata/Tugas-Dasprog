#include <stdio.h>
#include <stdlib.h>

/*
Nama Anggota
Ligar Arsa Arnata / 5025211244
Sony Hermawan / 5025211226
Imanuel Pascanov Samosir / 5025211257
*/

// 1. An Integer Divisible by 9

int get_input(){
printf("Enter an Integer:");
int n;
//get user input
scanf("%d",&n);
//get a valid number until between 1-999999
while(n<1 || n>999999){
printf("Enter between(1-999999):");
scanf("%d",&n);
}
return n;
}
void display(int val){
//set sum to zero
int sum = 0;
//set n to val
int n = val;
//while n has digits
while(n>0){
//print digit and add it to sum
printf("%d\n",n%10);
sum += n%10;
//reduce digit from back
n/=10;
}
//if sum is evenly divisible by 9.
if(sum%9==0){
printf("%d is divisible by 9\n",val);
}
else{
printf("%d is not divisible by 9\n",val);
}
}

int main(){
int val = get_input();
display(val);

return 0;
}


