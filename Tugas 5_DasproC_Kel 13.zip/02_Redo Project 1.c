#include <stdio.h>
#include <stdlib.h>

int main()

{
// 2. Redo Project 1

// Variable Declaration
int n;
// Get the Amount of n
printf("Enter Integer : ");
scanf("%d", &n);

// Loop Statement
int sum = 0;
while(n)
{
printf("%d ",n%10);
sum = sum+n%10;
n = n/10;
}

// If Statement
if(sum%9==0){
printf("\nTrue");
}else{
printf("\nFalse");
}

return 0;
}

