/*
 * Prompts for and stores the dimension data necessary to compute a
 * figure's area and perimeter. Figure returned contains a 'Q' in the
 * shape component when signaling end of data.
*/

#include "header.h"

figure_t
get_figure_dimensions(void)
{
    figure_t object;
    printf("Enter a letter to indicate the object shape or Q to quit.\n");
    printf("C (circle), R (rectangle), or S (square)> ");
    object.shape = getchar();

    switch (object.shape) {
    case 'C':
    case 'c':
    printf("Enter radius> ");
    scanf("%lf", &object.fig.circle.radius);
    break;

case 'R':
case 'r':
    printf("Enter height> ");
    scanf("%lf", &object.fig.rectangle.height);
    printf("Enter width> ");
    scanf("%lf", &object.fig.rectangle.width);
    break;

case 'S':
case 's':
    printf("Enter length of a side> ");
    scanf("%lf", &object.fig.square.side);
    break;

    default: /* Error is treated as a QUIT */
        object.shape = 'Q';
    }

    return (object);

}
