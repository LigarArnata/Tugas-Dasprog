
#include "header.h"

void print_figure(figure_t object)
{
   switch (object.shape)
   {
   case 'C':
   case 'c':
       printf("For a circle with a radius of %.2f, the area is %.2f and the circumference is %.2f\n\n",
           object.fig.circle.radius, object.fig.circle.area, object.fig.circle.circumference);
       break;

   case 'R':
   case 'r':
       printf("For a rectangle with a width of %.2f and a height of %.2f,\n",
           object.fig.rectangle.width, object.fig.rectangle.height);
       printf("the area is %.2f and the perimeter is %.2f\n\n",
           object.fig.rectangle.area, object.fig.rectangle.perimeter);
       break;

   case 'S':
   case 's':
       printf("For a square with a side length of %.2f, the area is %.2f and the perimeter is %.2f\n\n",
           object.fig.square.side, object.fig.square.area, object.fig.square.perimeter);
       break;

   default:
       printf("Error in shape code detected in print_figure\n\n");
   }
}
