
#include "header.h"

figure_t compute_perim(figure_t object)
{
   switch (object.shape)
   {
   case 'C':
   case 'c':
       object.fig.circle.circumference = 2 * PI * object.fig.circle.radius;
       break;
   case 'R':
   case 'r':
       object.fig.rectangle.perimeter = (2 *object.fig.rectangle.height) + (2 * object.fig.rectangle.width);
       break;
   case 'S':
   case 's':
       object.fig.square.perimeter = 4 * object.fig.square.side;
       break;
   default:
       printf("Error in shape code detected in compute_perim\n");
   }
   return object;
}
