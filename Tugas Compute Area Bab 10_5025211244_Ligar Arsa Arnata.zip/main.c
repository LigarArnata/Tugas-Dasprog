/*
Nama : Ligar Arsa Arnata
NRP  : 5025211244
*/

#include "header.h"

int
main(void)
{
    figure_t onefig;

    printf("Area and Perimeter Computation Program\n");

    for (onefig = get_figure_dimensions();
        onefig.shape != 'Q';
        onefig = get_figure_dimensions()) {
        onefig = compute_area(onefig);
        onefig = compute_perim(onefig);
        print_figure(onefig);
    }

    return (0);

}
