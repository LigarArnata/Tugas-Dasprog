/*
Functions to perform basic operations on sets of characters represented as strings.
Note: "Rest of set" is represented as &set[1], which is indeed the address of the
rest of the set excluding the first element.

This efficient representation, which does not recopy the rest of the set,
is an acceptable substring reference in these functions only because
the "rest of the set" is always passed strictly as an input argument.
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define SETSIZ 65 /* 52 uppercase and lowercase letters, 10 digits,{, }, and '\0' */
#define TRUE 1
#define FALSE 0

int is_empty(const char *set);
int is_element(char ele, const char *set);
int is_set(const char *set);
int is_subset(const char *sub, const char *set);
char *set_union(char *result, const char *set1, const char *set2);
void print_with_commas(const char *str);
void print_set(const char *set);
char *get_set(char *set);
