#include <stdio.h>
#include <stdlib.h>

int main()
{
// 7. Leap Year
    int month, day, year, hari_ke, february = 28;
// Get the Date
    printf("Enter Date (mm, dd, yyyy) : ");
    scanf("%d, %d, %d", &month, &day, &year);
// Equation Before Checking Leap Year
    hari_ke = day;
// Check for leap year
    if((year % 4 == 0 && year % 100 != 0)||(year % 400 == 0)){
        february = 29;
    }
// Switch Statement
     switch(month)
    {
        case 2:
            hari_ke += 31;
            break;
        case 3:
            hari_ke += 31+february;
            break;
        case 4:
            hari_ke += 31+february+31;
            break;
        case 5:
            hari_ke += 31+february+31+30;
            break;
        case 6:
            hari_ke += 31+february+31+30+31;
            break;
        case 7:
            hari_ke += 31+february+31+30+31+30;
            break;
        case 8:
            hari_ke += 31+february+31+30+31+30+31;
            break;
        case 9:
            hari_ke += 31+february+31+30+31+30+31+31;
            break;
        case 10:
            hari_ke += 31+february+31+30+31+30+31+31+30;
            break;
        case 11:
            hari_ke += 31+february+31+30+31+30+31+31+30+31;
            break;
        case 12:
            hari_ke += 31+february+31+30+31+30+31+31+30+31+30;
            break;
    }

    printf("That is day %d of %d", hari_ke, year);

// Return Statement
    if((year % 4 == 0 && year % 100 != 0)||(year % 400 == 0)){
        return 1;
    }else{
        return 0;
    }
}
