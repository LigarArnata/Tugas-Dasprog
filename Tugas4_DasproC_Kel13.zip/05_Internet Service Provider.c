#include <stdio.h>
#include <stdlib.h>

int main()
{
// 5. Internet Service Provider

// Variable Declaration
    double n;
// Get the Amount of Data Used
    printf("Enter the Amount of Data Used : ");
    scanf("%lf", &n);
// If-else Statement
    if( n > 0 && n <= 1){
        printf("Charge = 250");
    }else if( n > 1 && n <= 2){
        printf("Charge = 500");
    }else if( n > 2 && n <= 5){
        printf("Charge = 1000");
    }else if( n > 5 && n <= 10){
        printf("Charge = 1500");
    }else if( n >= 10){
        printf("Charge = 2000");
    }else{
        printf("Wrong Amount");
    }
    return 0;
}
