#include <stdio.h>
#include <stdlib.h>

int main()
{
// 6. x-y coordinates

// Variable Declaration
    double x,y;
// Get the Coordinates
    printf("Enter the x,y Coordinates : ");
    scanf("%lf, %lf", &x, &y);
// If else if statement
    if( x > 0 && y > 0){
        printf("(%.1f,%.1f) is in quadrant I", x, y);
    }else if( x < 0 && y > 0){
        printf("(%.1f, %.1f) is in quadrant II", x, y);
    }else if( x < 0 && y < 0){
        printf("(%.1f, %.1f) is in quadrant III", x, y);
    }else if( x > 0 && y < 0){
        printf("(%.1f, %.1f) is in quadrant IV", x, y);
    }else if(x == 0 && y == 0){
        printf("(%.1f, %.1f) is in Origin", x, y);
    }else if( x == 0 ){
        printf("(%.1f, %.1f) is in x Axis", x, y);
    }else if( y == 0){
        printf("(%.1f, %.1f) is in y Axis", x, y);
    }

    return 0;
}
