
// Ligar Arsa Arnata

/*
* Prompts the user to enter the search parameters
*/

#include "header.h"

search_params_t get_params() {

search_params_t params;
char chosen;

/*Initialize the search criteria's low and high bound to default.*/

params.low_stock= MIN_STOCK;
params.high_stock= MAX_STOCK;
params.low_price= MIN_PRICE;
params.high_price=MAX_PRICE;

strcpy(params.low_category,"AAAA");
strcpy(params.high_category,"zzzz");
strcpy(params.low_tech_descript,"AAAA");
strcpy(params.high_tech_descript,"zzzz");

// Once the user specifies which search criteria to change, get the new value for the search criteria from user.

    do{
        chosen= menu_choose(params);

    switch (chosen){

    case 'a':
    printf(" New Low bound for stock number> ");
    scanf("%d", params.low_stock);
    break;

    case 'b':
    printf(" New High bound for stock number> ");
    scanf("%d", params.high_stock);
    break;

    case 'c':
    printf(" New Low bound for Category> ");
    scanf("%s", params.low_category);
    break;

    case 'd':
    printf(" New High bound for Category> ");
    scanf("%s", params.high_category);
    break;

    case 'e':
    printf(" New Low bound for technical description> ");
    scanf("%s", params.low_tech_descript);
    break;

    case 'f':
    printf(" New High bound for technical description> ");
    scanf("%s", params.high_tech_descript);
    break;

    case 'g':
    printf(" New Low bound for price> ");
    scanf("%d", params.low_price);
    break;

    case 'h':
    printf(" New High bound for price> ");
    scanf("%d", params.high_price);
    break;

/*Validate the entries*/

    default:

    printf(" Not a valid entry. Please retry.");
}
}while(chosen!='q');
return params;
}
