
// Ligar Arsa Arnata 5025211244

#include "header.h"

int main(void) {

char inv_filename[STR_SIZ];

FILE *inventoryp,*inventorybp;
search_params_t params;
/*Get name of inventory file and open it */
printf("Enter name of inventory file> ");
scanf("%s", inv_filename);
inventoryp = fopen(inv_filename, "r");
inventorybp = fopen("binary.bin", "wb");
if(inventoryp == NULL )
printf("Text File does not exist. Please check.");
else{
make_product_file( inventoryp, inventorybp);
/*Get the search parameters */
params = get_params();
/*Display products that satisfy search criteria*/
display_match(inventoryp, params);
}
fclose(inventoryp);
fclose(inventorybp);
return(0);
}
