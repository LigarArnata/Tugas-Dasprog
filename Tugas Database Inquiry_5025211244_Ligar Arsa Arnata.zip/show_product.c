
// Ligar Arsa Arnata 5025211244

/*
* Displays each field of prod. Leaves a blank line after the product display.
*/

#include "header.h"

/* Displays each field of product information on a new line.*/

void show(product_t prod) {
printf("\n%d\t %s\t %s\t %7.2f", prod.stock_num, prod.category, prod.tech_descript, prod.price);

}
