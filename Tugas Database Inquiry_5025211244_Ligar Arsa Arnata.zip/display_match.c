
// Ligar Arsa Arnata 5025211244

/*
* Displays records of all products in the inventory that satisfy search parameters.
* Pre: databasep accesses a binary file of product_t records that has been opened
  as an input file, and params is defined
*/

#include "header.h"

void display_match(FILE *databasep, search_params_t params){
product_t next_prod; /*current product from database*/
int no_matches = 0; /*no of matches found*/
int status=1; /* input file status */
databasep = fopen("binary.bin", "rb");
status = fread(&next_prod, sizeof (product_t), 1, databasep);

/*Displays a list of the products that satisfy the search parameters*/
printf("\nProducts satisfying the search parameters:");
printf("\nStock No Category Description Price");
while (status >0) {
if (match(next_prod, params)) {
no_matches++;
show(next_prod);
}
status = fread(&next_prod, sizeof (product_t), 1, databasep);
}
/* Displays a message if no products found */
if (no_matches ==0)
printf("Sorry, no products available\n");
}
