
// Ligar Arsa Arnata 5025211244

#include "header.h"

void make_product_file(FILE *inventoryp, FILE *inventorybp){

product_t a_product;

int status=1;

while(status>0){
status=fscanf(inventoryp,"%d %s %s %lf", &a_product.stock_num, a_product.category, a_product.tech_descript, &a_product.price);
if(status==4){
fwrite(&a_product, sizeof (product_t), 1, inventorybp);
}

}
fclose(inventorybp);
}
