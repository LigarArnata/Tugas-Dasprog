
// Ligar Arsa Arnata 5025211244

/*
* Determines whether record prod satisfies all search parameters
*/

#include "header.h"

int match(product_t prod, search_params_t params) {

/*Compare information of product to the low and high bounds of search parameters. Return true if product falls between bounds.*/
return (strcmp(params.low_category, prod.category)<=0 && strcmp(prod.category, params.high_category)<=0 &&
params.low_stock <= prod.stock_num &&
prod.stock_num <= params.high_stock &&
params.low_price <= prod.price &&
prod.price <= params.high_price);
}
