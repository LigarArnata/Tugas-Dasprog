
#include <stdio.h>
#include <string.h>
#define RECORDS 20
FILE *inp;
int stats, ID[RECORDS], m_release[RECORDS], y_release[RECORDS], m_rearrest[RECORDS], y_rearrest[RECORDS];
void store();
void printdata();
double recidivism();

int main()
{
    char file[100];
    printf("Enter Data File Name\n(include the data type e.g. .txt / .docx)\n>> ");
    scanf("%s", &file);
    inp = fopen(file, "r");
    printf("\n------------------------------------------------------------------------------------------------");
    printf("\n| Offenders ID    Month of Release    Year of Release    Month of Rearrest    Year of Rearrest |");
    printf("\n------------------------------------------------------------------------------------------------");
    store();
    printdata();
    printf("\n------------------------------------------------------------------------------------------------");
    fclose(inp);
    printf("\n| RECIDIVISM RATE : %.1lf%%\t\t\t\t\t\t\t\t\t\b|", recidivism());
    printf("\n------------------------------------------------------------------------------------------------\n");

    return 0;
}

void
store()
{
    int status, i=0;
    status = fscanf(inp, "%d", &ID[i]);
    fscanf(inp, "%d", &m_release[i]);
    fscanf(inp, "%d", &y_release[i]);
    fscanf(inp, "%d", &m_rearrest[i]);
    fscanf(inp, "%d", &y_rearrest[i]);
    while(status==1)
    {
        i++;
        status = fscanf(inp, "%d", &ID[i]);
        fscanf(inp, "%d", &m_release[i]);
        fscanf(inp, "%d", &y_release[i]);
        fscanf(inp, "%d", &m_rearrest[i]);
        fscanf(inp, "%d", &y_rearrest[i]);
    }
}

void
printdata()
{
    int status,i=0;
    printf("\n| %3c%d", ' ',ID[i]);
    printf("\t\t%c%d", ' ',m_release[i]);
    printf("\t\t%3c%d", ' ',y_release[i]);
    printf("\t\t\t%d", m_rearrest[i]);
    printf("\t\t%3c%d\t\t\b|", ' ',y_rearrest[i]);
    i++;
    while(status!=0)
    {
        printf("\n| %3c%d", ' ',ID[i]);
        printf("\t\t%c%d", ' ',m_release[i]);
        printf("\t\t%3c%d", ' ',y_release[i]);
        printf("\t\t\t%d", m_rearrest[i]);
        printf("\t\t%3c%d\t\t\b|", ' ',y_rearrest[i]);
        i++;
        status = ID[i];
    }
}

double
recidivism()
{
    int year, i=0, status=1;
    double total=0;
    while(status!=0)
    {
        year = (((y_rearrest[i]-y_release[i]) * 12) + m_rearrest[i]) - m_release[i];
        if(year>=36)
            total++;
        i++;
        status = ID[i];
    }
    return ((total / i)*100);
}
