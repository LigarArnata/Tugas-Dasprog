#include <stdio.h>
#include <stdlib.h>

int main()
{
	double lalu[12], sekarang[12];
	int i, j;

	printf("Enter the monthly rainfall this year (from January - December) : ");
	for(i=0;i<12;i++)
	{
		scanf("%lf", &sekarang[i]);
	}

	printf("\nEnter the monthly rainfall last year (from January - December) : ");
	for(j=0;j<12;j++)
	{
		scanf("%lf", &lalu[j]);
	}

	printf("\n							Table of monthly rainfall\n");
	printf("	   	January  February      March      April        May       June       July     August  September    October   November   Desember\n");

	printf("This year : ");
	for(i=0;i<12;i++)
	{
		printf("%10.1lf ", sekarang[i]);
	}

	printf("\nLast year : ");
	for(j=0;j<12;j++)
	{
		printf("%10.1lf ", lalu[j]);
	}

	double sum_this, sum_last;
	for(i=0;i<12;i++)
	{
		sum_this += sekarang[i];
	}

	for(j=0;j<12;j++)
	{
		sum_last += lalu[j];
	}

	double avg_this = sum_this / 12, avg_last = sum_last / 12;

	printf("\n\nTotal rainfall this year : %.1lf", sum_this);

	printf("\nTotal rainfall last year : %.1lf", sum_last);

	printf("\n\nAverage monthly rainfall for this year : %.1lf", avg_this);

	printf("\nAverage monthly rainfall for last year : %.1lf", avg_last);
}

