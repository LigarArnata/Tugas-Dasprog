#include <stdio.h>

int main()
{
	int brs, klm, hasil, a;
	printf("X");
	for(a=6;a<=10;a++)
	{
		printf("%6d", a);
	}

	for(brs=6;brs<=10;brs++)
	{
		printf("\n \n%d ", brs);

		for(klm=6;klm<=10;klm++)
		{
			hasil = brs * klm;
			printf("%5d ", hasil);
		}
	}
	return 0;
}
